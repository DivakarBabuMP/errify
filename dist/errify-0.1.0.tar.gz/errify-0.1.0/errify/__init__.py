# __init__.py
from .errify import install, uninstall, register_handler, _explainer
install()  # auto-activate on import

__version__ = "0.1.0"
__author__ = "Divakar Babu M P"
__email__ = "divakarbabu369@gmail.com"
